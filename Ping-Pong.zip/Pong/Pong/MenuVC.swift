//
//  MenuVC.swift
//  Pong
//
//  Created by Guneet Singh on 2018-06-15.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit
import AVFoundation

enum gameType {
    case easy
    case medium
    case hard
    case player2
}

class MenuVC : UIViewController
{
    var audio = AVAudioPlayer()
    override func viewDidLoad() {
        do
        {
        audio = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "background1", ofType: "mp3")!))
            audio.prepareToPlay()
            audio.play()
            audio.numberOfLoops = -1
        }
        catch
        {
            print(error)
        }
        
    }

    
    @IBAction func Player2(_ sender: Any) {
        moveToGame(game: .player2)
        audio.stop()
    }
    
    @IBAction func Easy(_ sender: Any) {
        moveToGame(game: .easy)
        audio.stop()
    }
    
    @IBAction func Medium(_ sender: Any) {
        moveToGame(game: .medium)
        audio.stop()
    }
    
    @IBAction func Hard(_ sender: Any) {
        moveToGame(game: .hard)
        audio.stop()
    }
    
    @IBAction func exitB(_ sender: Any) {
        exit(0)
    }
    
    
    func moveToGame(game : gameType)
    {
        let gameVC = self.storyboard?.instantiateViewController(withIdentifier: "gameVC") as! GameViewController
        currentGameType = game
        self.navigationController?.pushViewController(gameVC, animated: true)
    }
}
